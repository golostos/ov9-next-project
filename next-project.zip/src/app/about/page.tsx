export default function About() {
  return (
    <div className="flex justify-center items-center h-24 w-[500px]">About page</div>
  )
}
